#include "buttons.h"
#include <avr/io.h>
#include <avr/interrupt.h>

/* ---------- Debouncer config ---------- */
#ifndef F_CPU
#  define F_CPU 20000000UL
#endif

/* Sample every 5 ms using TCB1 periodic interrupt:
   TCB1 clock = CLK_PER/2 => 20 MHz / 2 = 10 MHz
   CCMP = 10e6 * 0.005 - 1 = 49999 */
#define TCB1_CMP_5MS  (29999U)

/* PA pins for S1..S4 */
#define S1_PIN_bm PIN4_bm
#define S2_PIN_bm PIN5_bm
#define S3_PIN_bm PIN6_bm
#define S4_PIN_bm PIN7_bm
#define BTN_MASK  (S1_PIN_bm|S2_PIN_bm|S3_PIN_bm|S4_PIN_bm)

/* Debounced level of buttons (1=released due to pull-up, 0=pressed) */
static volatile uint8_t s_db_state = BTN_MASK;   /* start released */
static volatile uint8_t s_toggle = 0;            /* bits that toggled this sample */

/* For edge extraction in pop() */
static uint8_t s_prev_state = BTN_MASK;          /* last state seen by pop() */

/* 2-bit vertical counters (classic debounce), per bit */
ISR(TCB1_INT_vect)
{
    static uint8_t ct0 = 0, ct1 = 0;

    uint8_t sample = PORTA.IN & BTN_MASK;          /* read PA4..PA7 */
    uint8_t delta  = sample ^ s_db_state;          /* bits that are changing */

    /* update 2-bit counters only where delta=1 */
    ct0 = ~(ct0 & delta);
    ct1 = (ct1 ^ ct0) & delta;

    /* toggle when both counters overflow (after 4 consistent samples) */
    s_toggle   = delta & ct0 & ct1;
    s_db_state ^= s_toggle;

    TCB1.INTFLAGS = TCB_CAPT_bm;                   /* clear interrupt */
}

void buttons_init(void)
{
    /* Enable pull-ups; no pin interrupts (we sample in timer ISR) */
    PORTA.PIN4CTRL = PORT_PULLUPEN_bm;
    PORTA.PIN5CTRL = PORT_PULLUPEN_bm;
    PORTA.PIN6CTRL = PORT_PULLUPEN_bm;
    PORTA.PIN7CTRL = PORT_PULLUPEN_bm;

    /* TCB1 periodic interrupt @ 5 ms */
    TCB1.CTRLA = 0;                 /* off while configuring */
    TCB1.CNT   = 0;
    TCB1.CCMP  = TCB1_CMP_5MS;
    TCB1.CTRLB = TCB_CNTMODE_INT_gc;  /* periodic interrupt mode */
    TCB1.INTFLAGS = TCB_CAPT_bm;      /* clear flag */
    TCB1.INTCTRL  = TCB_CAPT_bm;      /* enable interrupt */
    TCB1.CTRLA = TCB_ENABLE_bm | TCB_CLKSEL_DIV2_gc;  /* start @ CLK/2 */

    /* Start clean */
    uint8_t s = SREG; cli();
    s_db_state  = PORTA.IN & BTN_MASK;
    s_prev_state = s_db_state;
    s_toggle = 0;
    SREG = s;
}

/* Return one falling-edge (released->pressed) after debounce, or -1 */
int8_t buttons_pop(void)
{
    int8_t result = -1;

    uint8_t s = SREG; cli();
    uint8_t curr = s_db_state;                 /* 1=released, 0=pressed */
    uint8_t prev = s_prev_state;
    SREG = s;

    /* Falling edge = prev 1 -> curr 0: detect per button */
    uint8_t falling = prev & (prev ^ curr) & BTN_MASK;

    if (falling) {
        if      (falling & S1_PIN_bm) result = 0;
        else if (falling & S2_PIN_bm) result = 1;
        else if (falling & S3_PIN_bm) result = 2;
        else if (falling & S4_PIN_bm) result = 3;

        /* consume exactly one button edge; leave others for next call */
        /* mark just that button as updated in prev_state */
        s = SREG; cli();
        s_prev_state ^= (1U << (4 + result));  /* flip the consumed bit */
        SREG = s;
    } else {
        /* no falling edges; keep prev_state synchronized periodically */
        s = SREG; cli();
        s_prev_state = curr;
        SREG = s;
    }

    return result;
}

uint8_t buttons_is_down(uint8_t idx)
{
    /* Debounced state: bit=1 → released, bit=0 → pressed */
    extern volatile uint8_t s_db_state;   // already in this file
    uint8_t mask = (uint8_t)(PIN4_bm << idx);   // idx:0..3 -> PA4..PA7
    return ((s_db_state & mask) == 0) ? 1u : 0u;
}

/* Clear any queued edges and align prev with current */
void buttons_clear_all(void)
{
    uint8_t s = SREG; cli();
    s_prev_state = s_db_state;
    /* also drop any lingering s_toggle information */
    s_toggle = 0;
    /* clear any PORTA flags in case user enabled pin ISCs elsewhere */
    PORTA.INTFLAGS = BTN_MASK;
    SREG = s;
}
