#include "timer.h"
#include <avr/io.h>
#include <avr/interrupt.h>

/* Monotonic millisecond counter */
volatile uint16_t elapsed_time = 0;

void timer_init(void) {
    // Configure TCB0 for a periodic interrupt every 1ms
    TCB0.CTRLA   = 0;                   // Disable while configuring
    TCB0.CNT     = 0;
    TCB0.CCMP    = 3333;                // 3.3 MHz / 3333 ≈ 1 kHz
    TCB0.CTRLB   = TCB_CNTMODE_INT_gc;  // Periodic interrupt mode
    TCB0.INTFLAGS = TCB_CAPT_bm;        // Clear any stale flag
    TCB0.INTCTRL  = TCB_CAPT_bm;        // Enable interrupt
    TCB0.CTRLA   = TCB_ENABLE_bm;       // Enable timer

    // Note: TCB1 is owned by buttons.c for debouncing and display multiplexing.
}

// periodic interrupt every 1ms
ISR(TCB0_INT_vect) {
    elapsed_time++;
    TCB0.INTFLAGS = TCB_CAPT_bm;
}
