// Simon Says game for QUTy microcontroller
#include <avr/io.h>
#include <avr/interrupt.h>
#include "initialisation.h"
#include "display.h"
#include "display_macros.h"
#include "buzzer.h"
#include "timer.h"
#include "sequencing.h"
#include "buttons.h"
#include "adc.h"
#include "uart.h"

#define FAIL_TONE_HZ 400

// Global state

// Notes:
// - Follow a non-blocking state machine (no busy-waits inside the switch)
// - Use elapsed_time (1ms tick) for timing

static uint32_t round_start_state = 0;
static uint8_t len = 0;
static uint8_t i = 0;
static uint8_t played_steps[64];
static uint16_t playback_delay_ms = 250;

static const uint8_t digit_masks[10] = {
    DISP_SEG_A & DISP_SEG_B & DISP_SEG_C & DISP_SEG_D & DISP_SEG_E & DISP_SEG_F,  // 0
    DISP_SEG_B & DISP_SEG_C,                                                        // 1
    DISP_SEG_A & DISP_SEG_B & DISP_SEG_G & DISP_SEG_E & DISP_SEG_D,                // 2
    DISP_SEG_A & DISP_SEG_B & DISP_SEG_C & DISP_SEG_D & DISP_SEG_G,                // 3
    DISP_SEG_F & DISP_SEG_G & DISP_SEG_B & DISP_SEG_C,                             // 4
    DISP_SEG_A & DISP_SEG_F & DISP_SEG_G & DISP_SEG_C & DISP_SEG_D,                // 5
    DISP_SEG_A & DISP_SEG_F & DISP_SEG_E & DISP_SEG_D & DISP_SEG_C & DISP_SEG_G,   // 6
    DISP_SEG_A & DISP_SEG_B & DISP_SEG_C,                                          // 7
    DISP_ON,                                                                        // 8
    DISP_SEG_A & DISP_SEG_B & DISP_SEG_C & DISP_SEG_D & DISP_SEG_F & DISP_SEG_G   // 9
};

static inline void enable_outputs(uint8_t step_index)
{
    static const uint8_t left_patterns[4] = {DISP_BAR_LEFT, DISP_BAR_RIGHT, DISP_OFF, DISP_OFF};
    static const uint8_t right_patterns[4] = {DISP_OFF, DISP_OFF, DISP_BAR_LEFT, DISP_BAR_RIGHT};
    display_set(left_patterns[step_index], right_patterns[step_index]);
    buzzer_on(step_index);
}

static inline void disable_outputs(void)
{
    buzzer_stop();
    display_blank();
}

// Safe timer check handling wrap-around (true if now-start >= duration)
static inline uint8_t timer_expired(uint16_t start, uint16_t duration)
{
    extern volatile uint16_t elapsed_time;
    return (uint16_t)(elapsed_time - start) >= duration;
}

int main(void)
{
    cli();
    gpio_init();
    spi_init_for_display();
    uart_init();
    buttons_init();
    display_init();
    buzzer_init();
    timer_init();
    adc_init();
    buzzer_stop();
    sequencing_init(0x11993251u);
    sei();
    
    // State machine
    typedef enum { GS_PLAYBACK, GS_INPUT, GS_SUCCESS, GS_FAIL } game_state_t;
    game_state_t gs = GS_PLAYBACK;
    uint8_t pb_state = 0xFF, pb_state_r = 0xFF, pb_falling;

    // Sub-states and timers
    enum { PB_ON, PB_OFF } pb_phase = PB_ON;   // playback phase
    uint8_t pb_idx = 0;                        // which step we are on for playback
    uint16_t phase_start = 0;                  // start tick of current phase

    enum { IE_IDLE, IE_ECHOING, IE_WAIT_RELEASE } ie = IE_IDLE; // input echo phase
    int8_t echo_btn = -1;                      // button being echoed (0..3)
    uint16_t echo_start = 0;                   // echo start time
    uint16_t echo_duration = 120;              // will update from playback_delay_ms

    enum { FAIL_TONE, FAIL_SHOW, FAIL_PAUSE, FAIL_RESET } fs = FAIL_TONE; // fail phases
    uint16_t fail_start = 0;                   // phase start
    uint8_t score_tens = 0, score_ones = 0;    // cached masks for score display
    
    while (1) {
        // Update button state
        pb_state_r = pb_state;
        pb_state = buttons_get_debounced_state();
        pb_falling = (pb_state_r ^ pb_state) & pb_state_r;
        
        switch (gs) {
        case GS_PLAYBACK:
            // Start of a new round: extend sequence and prepare playback
            if (pb_idx == 0 && pb_phase == PB_ON) {
                if (len == 0) {
                    round_start_state = sequencing_save_state();
                }
                len++;
                playback_delay_ms = playback_delay_ms_from_adc8(adc_read8());
                echo_duration = (playback_delay_ms >> 1);
                sequencing_restore_state(round_start_state);
                for (uint8_t j = 0; j < len; j++) {
                    played_steps[j] = sequencing_next_step();
                }
                // Kick off first step ON phase
                enable_outputs(played_steps[0]);
                phase_start = elapsed_time;
            }

            // Advance playback phases without blocking
            if (pb_phase == PB_ON) {
                if (timer_expired(phase_start, playback_delay_ms)) {
                    disable_outputs();
                    pb_phase = PB_OFF;
                    phase_start = elapsed_time;
                }
            } else { // PB_OFF
                if (timer_expired(phase_start, playback_delay_ms >> 1)) { // gap
                    pb_idx++;
                    if (pb_idx >= len) {
                        // Playback complete: prepare for input
                        i = 0;
                        pb_idx = 0;
                        pb_phase = PB_ON;
                        pb_state = buttons_get_debounced_state();
                        pb_state_r = pb_state;
                        uart_game_input = -1;
                        uart_input_enabled = 1;
                        ie = IE_IDLE;
                        gs = GS_INPUT;
                    } else {
                        // Next step ON
                        enable_outputs(played_steps[pb_idx]);
                        pb_phase = PB_ON;
                        phase_start = elapsed_time;
                    }
                }
            }
            break;
            
        case GS_INPUT: {
            // 1) Capture input only when idle
            if (ie == IE_IDLE) {
                int8_t b = -1;
                if (uart_game_input >= 0) {
                    b = uart_game_input;
                    uart_game_input = -1;
                } else {
                    if (pb_falling & PIN4_bm) b = 0;
                    else if (pb_falling & PIN5_bm) b = 1;
                    else if (pb_falling & PIN6_bm) b = 2;
                    else if (pb_falling & PIN7_bm) b = 3;
                }
                if (b >= 0) {
                    echo_btn = b;
                    enable_outputs((uint8_t)echo_btn);
                    echo_start = elapsed_time;
                    ie = IE_ECHOING;
                } else {
                    break; // no input yet
                }
            }

            // 2) Finish echo after duration, then wait for release
            if (ie == IE_ECHOING && timer_expired(echo_start, echo_duration)) {
                disable_outputs();
                ie = IE_WAIT_RELEASE;
            }
            if (ie == IE_WAIT_RELEASE) {
                uint8_t mask = (uint8_t)(1u << (echo_btn + 4));
                if ((buttons_get_debounced_state() & mask) != 0) {
                    // Released -> validate
                    if ((uint8_t)echo_btn == played_steps[i]) {
                        i++;
                        if (i == len) {
                            // Round success
                            cli();
                            uart_input_enabled = 0;
                            sei();
                            display_set(DISP_ON, DISP_ON);
                            phase_start = elapsed_time;
                            gs = GS_SUCCESS;
                        } else {
                            ie = IE_IDLE; // next input
                        }
                    } else {
                        // Fail
                        cli();
                        uart_input_enabled = 0;
                        sei();
                        fs = FAIL_TONE;
                        fail_start = elapsed_time;
                        gs = GS_FAIL;
                    }
                }
            }
            break; }

        case GS_SUCCESS:
            // Show both digits lit briefly then return to playback
            if (timer_expired(phase_start, playback_delay_ms)) {
                display_blank();
                gs = GS_PLAYBACK;
            }
            break;
            
        case GS_FAIL:
            switch (fs) {
                case FAIL_TONE:
                    playback_delay_ms = playback_delay_ms_from_adc8(adc_read8());
                    display_set(DISP_DASH, DISP_DASH);
                    buzzer_start_hz(FAIL_TONE_HZ);
                    if (timer_expired(fail_start, playback_delay_ms)) {
                        buzzer_stop();
                        // Prepare score masks and show
                        uint8_t show = (uint8_t)(len % 100);
                        uint8_t tens = show / 10, ones = show % 10;
                        uint8_t left_mask = (tens == 0 && len < 100) ? DISP_OFF : digit_masks[tens];
                        score_tens = left_mask;
                        score_ones = digit_masks[ones];
                        display_set(score_tens, score_ones);
                        fail_start = elapsed_time;
                        fs = FAIL_SHOW;
                    }
                    break;
                case FAIL_SHOW:
                    if (timer_expired(fail_start, playback_delay_ms)) {
                        display_blank();
                        fail_start = elapsed_time;
                        fs = FAIL_PAUSE;
                    }
                    break;
                case FAIL_PAUSE:
                    if (timer_expired(fail_start, playback_delay_ms >> 1)) {
                        // Advance RNG and reset
                        sequencing_restore_state(round_start_state);
                        for (uint8_t j = 0; j < len; j++) (void)sequencing_next_step();
                        len = 0;
                        pb_idx = 0;
                        pb_phase = PB_ON;
                        gs = GS_PLAYBACK;
                        fs = FAIL_TONE;
                    }
                    break;
                default:
                    fs = FAIL_TONE;
            }
            break;
        }
    }
}
