// src/main.c
#include <avr/io.h>
#include <avr/interrupt.h>
#include "initialisation.h"
#include "display.h"
#include "display_macros.h"
#include "buzzer.h"
#include "timer.h"
#include "sequencing.h"
#include "buttons.h"
#include "adc.h"

static void state_machine(void);

/* ---------- Timing & tones ---------- */
#define STEP_DELAY_MS     1200              /* default; replaced each round by POT */
#define ROUND_PAUSE_MS    1200
#define INPUT_GUARD_MS      20
#define FAIL_MS            250              /* not used when fail tied to step delay */

/* TODO: set to exact spec tones if provided */
#define SUCCESS_TONE_HZ   1200
#define FAIL_TONE_HZ       400
#define WIN_LENGTH          3              /* change if your brief says otherwise */
#define WIN_TONE_HZ       1400
#define WIN_HOLD_MS   (2*STEP_DELAY_MS)

typedef enum { GS_WAIT_START, GS_PLAYBACK, GS_INPUT, GS_FAIL } game_state_t;

int main(void)
{
    cli();

    clock_init_20mhz();       /* 20 MHz, no prescale */
    gpio_init();              /* display latch pin etc. */
    spi_init_for_display();   /* SPI0 host for 74HC595 */
    tcb0_init_1ms();          /* 1 ms system tick (millis/delay_ms) */
    buttons_init();           /* S1..S4 debounced sampler on TCB1 */
    display_init();           /* blank display */
    buzzer_init();            /* TCA0 WO0 on PB0 */
    adc_init_pot_8bit();      /* free-run 8-bit on POT (AIN2) */
    buzzer_stop();

    /* Seed LFSR with your student number */
    sequencing_init(0x11993251u);

    sei();

    state_machine();

    while (1) { }             /* should never return */
}

/* ---------------- Game state machine ----------------
   Flow:
   - GS_WAIT_START: wait for any S1..S4 press to begin
   - GS_PLAYBACK:   extend sequence by one, replay entire sequence
   - GS_INPUT:      wait for user presses; compare to sequence
   - GS_FAIL:       show dashes + tone, then reset to WAIT_START
------------------------------------------------------ */
static void state_machine(void)
{
    static uint8_t seq[64];
    static uint8_t len = 0;
    static uint8_t i = 0;
    game_state_t gs = GS_WAIT_START;

    /* Keep the current round’s delay persistent across cases/iterations */
    static uint16_t current_step_delay_ms = STEP_DELAY_MS;

    uint32_t guard_until = 0;

    while (1) {
        switch (gs) {

        case GS_WAIT_START:
            display_blank();
            buzzer_stop();
            /* Do NOT clear buttons here; accept any queued press instantly */
            if (buttons_pop() >= 0) {          /* any press starts */
                len = 0;
                gs = GS_PLAYBACK;
            }
            break;

        case GS_PLAYBACK: {
            if (len < sizeof seq) seq[len++] = sequencing_next_step();

            buttons_clear_all();               /* ignore presses during playback */

            /* Sample POT once per round (0.25–2.0 s) */
            uint8_t pot = adc_read8();
            current_step_delay_ms = playback_delay_ms_from_adc8(pot);

            play_sequence(seq, len, current_step_delay_ms);  /* 50/50 inside */
            buttons_clear_all();               /* drop anything that happened */

            i = 0;
            guard_until = millis() + INPUT_GUARD_MS;
            gs = GS_INPUT;
            break;
        }

        case GS_INPUT: {
            /* brief guard to ignore latent edges right after playback */
            if ((int32_t)(millis() - guard_until) < 0) {
                buttons_clear_all();
                break;
            }

            int8_t b = buttons_pop();
            if (b < 0) break;  /* no press yet */

            uint8_t expected = seq[i];
            if ((uint8_t)b == expected) {
                /* Show correct bars + play the step tone for ≥ 1/2 delay, or as long as held */
                extern const uint16_t step_freq[4];  /* declared in sequencing.h */

                if (b < 2) {
                    display_write_lhs((b == 0) ? (DISP_SEG_E & DISP_SEG_F)
                                               : (DISP_SEG_B & DISP_SEG_C));
                } else {
                    display_write_rhs((b == 2) ? (DISP_SEG_E & DISP_SEG_F)
                                               : (DISP_SEG_B & DISP_SEG_C));
                }
                buzzer_start_hz(step_freq[b]);

                uint16_t min_on = current_step_delay_ms / 2;
                uint32_t t0 = millis();
                while ((uint32_t)(millis() - t0) < min_on) { /* keep on for ≥ 1/2 delay */ }
                while (buttons_is_down((uint8_t)b)) {
                    if ((uint32_t)(millis() - t0) > (uint32_t)(current_step_delay_ms * 2U)) break; /* safety cap */
                }

                buzzer_stop();
                display_blank();

                i++;
                if (i == len) {
                    /* SUCCESS: “8 8” on both digits for one full step delay + success tone */
                    buzzer_start_hz(SUCCESS_TONE_HZ);
                    uint32_t s0 = millis();
                    while ((uint32_t)(millis() - s0) < current_step_delay_ms) {
                        display_write_lhs(DISP_ON);
                        delay_ms(1);
                        display_write_rhs(DISP_ON);
                        delay_ms(1);
                    }
                    buzzer_stop();
                    display_blank();

                    /* Win condition */
                    if (len >= WIN_LENGTH) {
                        /* WIN pattern: hold “8 8” a bit longer with a different tone */
                        buzzer_start_hz(WIN_TONE_HZ);
                        uint32_t w0 = millis();
                        while ((uint32_t)(millis() - w0) < WIN_HOLD_MS) {
                            display_write_lhs(DISP_ON);
                            delay_ms(1);
                            display_write_rhs(DISP_ON);
                            delay_ms(1);
                        }
                        buzzer_stop();
                        display_blank();

                        /* reset game */
                        len = 0;
                        buttons_clear_all();
                        gs = GS_WAIT_START;
                    } else {
                        /* otherwise continue to next round */
                        delay_ms(ROUND_PAUSE_MS);
                        gs = GS_PLAYBACK;
                    }
                }
            } else {
                gs = GS_FAIL;
            }
            break;
        }

        case GS_FAIL: {
            /* FAIL: “– –” (dash both digits) for one step delay + fail tone */
            buzzer_start_hz(FAIL_TONE_HZ);
            uint32_t f0 = millis();
            while ((uint32_t)(millis() - f0) < current_step_delay_ms) {
                display_write_lhs(DISP_DASH);
                delay_ms(1);
                display_write_rhs(DISP_DASH);
                delay_ms(1);
            }
            buzzer_stop();
            display_blank();

            buttons_clear_all();
            gs = GS_WAIT_START;
            break;
        }

        } /* switch */
    } /* while */
}
