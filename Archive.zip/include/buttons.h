#ifndef BUTTONS_H
#define BUTTONS_H

#include <stdint.h>

/* Initialise debouncer on TCB1 (5 ms), PA4..PA7 pull-ups enabled */
void buttons_init(void);

/* Pop one press event (falling edge after debounce):
   returns: 0=S1 (PA4), 1=S2 (PA5), 2=S3 (PA6), 3=S4 (PA7), or -1 if none */
int8_t buttons_pop(void);

/* Clear any queued/latent edges so next pop() starts fresh */
void buttons_clear_all(void);

/* Is button idx (0=S1..3=S4) currently held down (debounced)? 1=yes, 0=no */
uint8_t buttons_is_down(uint8_t idx);


#endif
