#ifndef INITIALISATION_H
#define INITIALISATION_H

#include <stdint.h>

void gpio_init(void);
void spi_init_for_display(void);

#endif