#ifndef TIMER_H
#define TIMER_H

#include <stdint.h>

/* Global millisecond tick incremented by TCB0 ISR */
extern volatile uint16_t elapsed_time;

/* Initialise TCB0 to generate a 1 ms periodic interrupt updating elapsed_time */
void timer_init(void);

#endif
